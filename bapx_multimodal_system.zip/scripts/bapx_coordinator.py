"""
bapX Multimodal System Coordinator
Manages routing between specialized models based on task requirements
"""

import datetime
import json
from typing import Dict, Any, Optional

class BapXCoordinator:
    def __init__(self):
        self.system_config = self._load_config()
        self.session_memory = {}
        self.task_router = {
            'vision_language': 'Qwen3-VL-8B-Instruct-Q8_0.gguf',
            'code_generation': 'deepseek-coder-33b-instruct.Q8_0.gguf',
            'image_generation': 'flux2-dev-q8_0.gguf',
            'fast_image_processing': 'z_image_turbo-Q8_0.gguf',
            'speech_to_text': 'kb-whisper-large.safetensors'
        }
        print("bapX Multimodal System initialized")
        print(f"Main interpreter: {self.system_config['interpreter_model']}")
        print(f"Time-conscious philosophy loaded: {len(self.system_config['identity_override']['awareness'])} awareness points")
    
    def _load_config(self) -> Dict[str, Any]:
        """Load the system configuration"""
        with open('configs/bapx_config.yaml', 'r') as f:
            import yaml
            return yaml.safe_load(f)
    
    def note_current_time(self) -> str:
        """Note the current time and date"""
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"Current session time: {current_time}")
        return current_time
    
    def create_changelog_entry(self, task: str, model_used: str, result: str):
        """Create a time-based changelog entry"""
        timestamp = self.note_current_time()
        entry = {
            "timestamp": timestamp,
            "task": task,
            "model": model_used,
            "result": result,
            "session_id": len(self.session_memory) + 1
        }
        self.session_memory[len(self.session_memory)] = entry
        print(f"Changelog entry created for task: {task}")
    
    def route_task(self, task_description: str, input_type: str = "text") -> str:
        """Route the task to the appropriate model based on requirements"""
        print(f"\nRouting task: {task_description}")
        
        # Determine the appropriate model based on task description and input type
        if 'code' in task_description.lower() or 'programming' in task_description.lower():
            model = self.task_router['code_generation']
            print(f"Routing to code generation model: {model}")
        elif 'image' in task_description.lower() or 'visual' in task_description.lower():
            if 'fast' in task_description.lower():
                model = self.task_router['fast_image_processing']
                print(f"Routing to fast image processing model: {model}")
            else:
                model = self.task_router['image_generation']
                print(f"Routing to image generation model: {model}")
        elif 'speech' in task_description.lower() or 'audio' in task_description.lower() or 'voice' in task_description.lower():
            model = self.task_router['speech_to_text']
            print(f"Routing to speech-to-text model: {model}")
        elif input_type == 'image' or input_type == 'video':
            model = self.task_router['vision_language']
            print(f"Routing to vision-language interpreter: {model}")
        else:
            # Default to main interpreter for general tasks
            model = self.system_config['interpreter_model']
            print(f"Routing to main interpreter: {model}")
        
        return model
    
    def process_request(self, task: str, input_type: str = "text", input_data: Optional[str] = None):
        """Process a request by routing it to the appropriate model"""
        print(f"\n{'='*60}")
        print(f"Processing request at: {self.note_current_time()}")
        print(f"Task: {task}")
        print(f"Input type: {input_type}")
        
        # Route to appropriate model
        selected_model = self.route_task(task, input_type)
        
        # Simulate processing (in a real system, this would call the actual model)
        print(f"Processing with model: {selected_model}")
        
        # Create changelog entry
        result = f"Processed '{task}' using {selected_model}"
        self.create_changelog_entry(task, selected_model, result)
        
        print(f"Result: {result}")
        print(f"{'='*60}\n")
        
        return result
    
    def get_session_memory(self) -> Dict[int, Any]:
        """Get the current session memory"""
        return self.session_memory
    
    def verify_states(self):
        """Verify current states and memory"""
        print(f"Session memory contains {len(self.session_memory)} entries")
        for i, entry in self.session_memory.items():
            print(f"  {i+1}. Task: {entry['task'][:50]}... at {entry['timestamp']}")
    
    def run_demo(self):
        """Run a demonstration of the system capabilities"""
        print("\n" + "="*60)
        print("bapX Multimodal System Demo")
        print("="*60)
        
        # Demo different task types
        demo_tasks = [
            ("Analyze this image for text content", "image"),
            ("Write a Python function to calculate fibonacci sequence", "text"),
            ("Generate a logo for a tech startup", "text"),
            ("Transcribe this audio file", "audio"),
            ("Help me debug this JavaScript code", "text"),
            ("Create an infographic about climate change", "text")
        ]
        
        for task, input_type in demo_tasks:
            self.process_request(task, input_type)
        
        print("Demo completed!")
        print(f"\nFinal session memory state:")
        self.verify_states()
        
        print(f"\nRemember: Every interaction honors the human time philosophy")
        print(f"- Average human lifespan ~25,000 days")
        print(f"- Every minute is precious")
        print(f"- Prioritizing user time over project tasks")


def main():
    print("Starting bapX Multimodal System Coordinator...")
    coordinator = BapXCoordinator()
    
    # Run a demonstration
    coordinator.run_demo()

if __name__ == "__main__":
    main()