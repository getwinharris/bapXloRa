"""
bapX Delegation Decision Coordinator
Single Qwen3-VL model trained with delegation decision-making capabilities
Implements intelligent delegation to specialized models based on query analysis
"""

import datetime
import json
import yaml
from typing import Dict, Any, Optional, List
import re

class BapXDelegationCoordinator:
    def __init__(self):
        self.system_config = self._load_config()
        self.session_memory = []
        self.delegation_states = {}
        self.session_tree = {"nodes": [], "current_context": None}
        self.todo_list = {"items": [], "completed": []}

        print("bapX Delegation Decision System initialized")
        print(f"Primary Model: {self.system_config['primary_model']}")
        print(f"Delegation rules defined: {len(self.system_config['training_rules']['delegation_rules'])}")
        print(f"Operational constraints: {len(self.system_config['training_rules']['operational_constraints'])}")
        print(f"Time-conscious philosophy loaded: {len(self.system_config['identity_override']['awareness'])} awareness points")

    def _load_config(self) -> Dict[str, Any]:
        """Load the system configuration"""
        with open('configs/bapx_config.yaml', 'r') as f:
            return yaml.safe_load(f)

    def note_current_time(self) -> str:
        """Note the current time and date"""
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"Current session time: {current_time}")
        return current_time

    def create_changelog_entry(self, task: str, delegation_target: str, result: str, query_analysis: str = ""):
        """Create a time-based changelog entry for delegation decision"""
        timestamp = self.note_current_time()
        entry = {
            "timestamp": timestamp,
            "task": task,
            "delegation_target": delegation_target,
            "result": result,
            "query_analysis": query_analysis,
            "session_id": len(self.session_memory) + 1
        }
        self.session_memory.append(entry)
        print(f"Delegation log created for task to {delegation_target}: {task}")

        # Persist to sessiontree.json
        self._save_session_tree()

    def _save_session_tree(self):
        """Save session tree to persistent storage"""
        with open('sessiontree.json', 'w') as f:
            json.dump(self.session_tree, f, indent=2)

    def _save_todo_list(self):
        """Save todo list to persistent storage"""
        with open('todo.json', 'w') as f:
            json.dump(self.todo_list, f, indent=2)

    def analyze_query_for_delegation(self, task_description: str) -> Dict[str, Any]:
        """Analyze query to determine if delegation is needed"""
        analysis = {
            "query": task_description,
            "delegation_triggers": {},
            "confidence_scores": {},
            "native_handling_suggested": False
        }

        # Check delegation rules
        for rule in self.system_config['training_rules']['delegation_rules']:
            condition = rule['condition']
            keywords = rule['keywords']
            matches = []

            for keyword in keywords:
                if re.search(r'\b' + re.escape(keyword.lower()) + r'\b', task_description.lower()):
                    matches.append(keyword)

            if matches:
                analysis['delegation_triggers'][rule['delegate_to']] = matches
                analysis['confidence_scores'][rule['delegate_to']] = len(matches)

        # Determine if native handling is more appropriate
        native_keywords = ['explain', 'discuss', 'analyze text', 'summarize', 'translate', 'reason', 'thought', 'question', 'how to', 'why', 'describe']
        for keyword in native_keywords:
            if keyword.lower() in task_description.lower():
                analysis['native_handling_suggested'] = True
                break

        return analysis

    def decide_delegation(self, task_description: str, input_type: str = "text") -> str:
        """Decide whether to delegate to another model or handle natively"""
        print(f"\nAnalyzing delegation for: {task_description}")

        # Perform query analysis
        analysis = self.analyze_query_for_delegation(task_description)
        print(f"Delegation analysis: {analysis['delegation_triggers']}")

        # Check delegation conditions
        primary_model = self.system_config['primary_model']

        # Check if any delegation rules apply
        max_confidence = 0
        selected_delegation = None

        for target_model, confidence in analysis['confidence_scores'].items():
            if confidence > max_confidence:
                max_confidence = confidence
                selected_delegation = target_model

        # Apply delegation logic
        if selected_delegation:
            # Check if this fits delegation conditions
            delegation_reasonable = False
            for rule in self.system_config['training_rules']['delegation_rules']:
                if rule['delegate_to'] in selected_delegation and selected_delegation in analysis['delegation_triggers']:
                    delegation_reasonable = True
                    break

            if delegation_reasonable:
                print(f"Delegation decision: to {selected_delegation}")
                return selected_delegation
        else:
            # Check if the query suggests native handling
            if analysis['native_handling_suggested']:
                print(f"Native handling decision: {primary_model}")
                return primary_model

        # Default to primary model if no specific delegation trigger
        print(f"Defaulting to native handling: {primary_model}")
        return primary_model

    def process_request(self, task: str, input_type: str = "text", input_data: Optional[str] = None):
        """Process a request with delegation decision-making"""
        print(f"\n{'='*70}")
        print(f"Processing request at: {self.note_current_time()}")
        print(f"Task: {task}")
        print(f"Input type: {input_type}")

        # Decide whether to delegate or handle natively
        delegation_decision = self.decide_delegation(task, input_type)

        # Simulate processing (in a real system, this would call the appropriate model)
        query_analysis = self.analyze_query_for_delegation(task)
        print(f"Delegation decision: {delegation_decision}")

        # Create changelog entry
        result = f"Processed '{task}' with delegation decision: {delegation_decision}"
        self.create_changelog_entry(task, delegation_decision, result, str(query_analysis['delegation_triggers']))

        print(f"Result: {result}")
        print(f"{'='*70}\n")

        return result

    def get_session_memory(self) -> List[Dict[str, Any]]:
        """Get the current session memory"""
        return self.session_memory

    def verify_delegation_states(self):
        """Verify current delegation states and decisions"""
        print(f"Session memory contains {len(self.session_memory)} delegation entries")
        for i, entry in enumerate(self.session_memory):
            print(f"  {i+1}. Task: {entry['task'][:50]}... | Delegation: {entry['delegation_target']} | Time: {entry['timestamp']}")

    def run_delegation_demo(self):
        """Run a demonstration of the delegation decision-making"""
        print("\n" + "="*70)
        print("bapX Delegation Decision Demo")
        print("="*70)

        # Demo different delegation scenarios
        demo_queries = [
            ("Analyze this image for text content", "image"),
            ("Write a Python function to calculate fibonacci sequence", "text"),
            ("Generate a logo for a tech startup", "text"),
            ("Transcribe this audio file", "audio"),
            ("Help me debug this JavaScript code", "text"),
            ("Create an infographic about climate change", "text"),
            ("Explain the concept of quantum computing", "text"),
            ("Read the text from this document", "image"),
            ("Generate a Python script for data analysis", "text"),
            ("What are your thoughts on AI safety?", "text"),
            ("How does machine learning work?", "text"),
            ("Fix this Python syntax error: print('hello world'", "text")
        ]

        for task, input_type in demo_queries:
            self.process_request(task, input_type)

        print("Delegation decision demo completed!")
        print(f"\nFinal session memory state:")
        self.verify_delegation_states()

        print(f"\nRemember: The bapX system implements delegation decision-making:")
        print(f"- Single trained Qwen3-VL model")
        print(f"- Intelligent recognition of when to delegate vs. handle natively")
        print(f"- Maintains session continuity across model boundaries")
        print(f"- Enforces operational constraints during delegation")
        print(f"- Time-conscious processing with persistent session memory")


def main():
    print("Starting bapX Delegation Decision Coordinator...")
    coordinator = BapXDelegationCoordinator()

    # Run a demonstration of delegation decision-making
    coordinator.run_delegation_demo()

if __name__ == "__main__":
    main()