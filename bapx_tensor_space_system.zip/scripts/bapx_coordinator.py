"""
bapX Tensor-Space Coordinator
Runtime-coordinated multimodal operator with time consciousness
Implements tensor-space architecture with Qwen3-VL as interpreter
"""

import datetime
import json
import yaml
from typing import Dict, Any, Optional, List
import re

class BapXTensorSpaceCoordinator:
    def __init__(self):
        self.system_config = self._load_config()
        self.session_memory = []
        self.tensor_space_states = {}
        self.session_tree = {"nodes": [], "current_context": None}
        self.todo_list = {"items": [], "completed": []}

        print("bapX Tensor-Space System initialized")
        print(f"Interpreter: {self.system_config['interpreter_model']}")
        print(f"Tensor spaces defined: {len(self.system_config['tensor_spaces'])}")
        print(f"Time-conscious philosophy loaded: {len(self.system_config['identity_override']['awareness'])} awareness points")

    def _load_config(self) -> Dict[str, Any]:
        """Load the system configuration"""
        with open('configs/bapx_config.yaml', 'r') as f:
            return yaml.safe_load(f)

    def note_current_time(self) -> str:
        """Note the current time and date"""
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"Current session time: {current_time}")
        return current_time

    def create_changelog_entry(self, task: str, tensor_space: str, result: str, query_analysis: str = ""):
        """Create a time-based changelog entry"""
        timestamp = self.note_current_time()
        entry = {
            "timestamp": timestamp,
            "task": task,
            "tensor_space": tensor_space,
            "result": result,
            "query_analysis": query_analysis,
            "session_id": len(self.session_memory) + 1
        }
        self.session_memory.append(entry)
        print(f"Changelog entry created for task in {tensor_space}: {task}")

        # Persist to sessiontree.json
        self._save_session_tree()

    def _save_session_tree(self):
        """Save session tree to persistent storage"""
        with open('sessiontree.json', 'w') as f:
            json.dump(self.session_tree, f, indent=2)

    def _save_todo_list(self):
        """Save todo list to persistent storage"""
        with open('todo.json', 'w') as f:
            json.dump(self.todo_list, f, indent=2)

    def analyze_query(self, task_description: str) -> Dict[str, Any]:
        """Analyze query to determine appropriate tensor space"""
        analysis = {
            "query": task_description,
            "matched_keywords": {},
            "confidence_scores": {},
            "contextual_factors": []
        }

        # Keyword matching for each tensor space
        for tensor_space in self.system_config['tensor_spaces']:
            name = tensor_space['name']
            keywords = tensor_space.get('activation_keywords', [])
            matches = []

            for keyword in keywords:
                if re.search(r'\b' + re.escape(keyword) + r'\b', task_description.lower()):
                    matches.append(keyword)

            if matches:
                analysis['matched_keywords'][name] = matches
                # Simple confidence based on number of keyword matches
                analysis['confidence_scores'][name] = len(matches)

        return analysis

    def route_to_tensor_space(self, task_description: str, input_type: str = "text") -> str:
        """Route task to appropriate tensor space based on query analysis"""
        print(f"\nAnalyzing query: {task_description}")

        # Perform query analysis
        analysis = self.analyze_query(task_description)
        print(f"Query analysis: {analysis['matched_keywords']}")

        # Apply priority ordering to select tensor space
        priority_order = self.system_config['routing_rules']['priority_order']

        # Check for matches in priority order
        selected_tensor_space = None
        for tensor_space_name in priority_order:
            if tensor_space_name in analysis['confidence_scores']:
                selected_tensor_space = tensor_space_name
                break

        # Fallback if no specific match
        if not selected_tensor_space:
            selected_tensor_space = self.system_config['routing_rules']['fallback_route']
            print(f"No specific match found, using fallback: {selected_tensor_space}")
        else:
            print(f"Selected tensor space based on priority: {selected_tensor_space}")

        # Apply contextual overrides only when appropriate
        original_tensor_space = selected_tensor_space
        for override in self.system_config['routing_rules']['contextual_overrides']:
            condition = override['condition']
            if condition == "previous_task_was_code_related" and self._was_previous_task_code_related():
                # Only apply if current task is also code-related
                if "code" in selected_tensor_space or "code" in task_description.lower():
                    override_to = override['override_to']
                    print(f"Contextual override applied: {condition} -> route to {override_to}")
                    selected_tensor_space = override_to
            elif condition == "previous_task_was_visual_related" and self._was_previous_task_visual_related():
                # Only apply if current task is also visual-related
                if "vision" in selected_tensor_space or any(keyword in task_description.lower()
                                                           for keyword in ["image", "visual", "photo", "video"]):
                    override_to = override['override_to']
                    print(f"Contextual override applied: {condition} -> route to {override_to}")
                    selected_tensor_space = override_to
            elif condition == "time_conscious_request" and "time" in task_description.lower():
                print(f"Contextual action applied: {override['action']}")

        # If override didn't change the selection, use the priority-based selection
        if selected_tensor_space == original_tensor_space:
            print(f"Final tensor space selection: {selected_tensor_space}")

        # Get the actual file name for this tensor space
        for tensor_space in self.system_config['tensor_spaces']:
            if tensor_space['name'] == selected_tensor_space:
                actual_file = tensor_space['file']
                print(f"Routing to tensor space: {actual_file}")
                return actual_file

        # Fallback to language tensor space file
        for tensor_space in self.system_config['tensor_spaces']:
            if tensor_space['name'] == self.system_config['routing_rules']['fallback_route']:
                return tensor_space['file']

        return self.system_config['interpreter_model']

    def _was_previous_task_code_related(self) -> bool:
        """Check if previous task was code related"""
        if not self.session_memory:
            return False
        last_task = self.session_memory[-1]['task'].lower()
        code_keywords = ['code', 'program', 'function', 'debug', 'javascript', 'python', 'java', 'c++', 'algorithm']
        return any(keyword in last_task for keyword in code_keywords)

    def _was_previous_task_visual_related(self) -> bool:
        """Check if previous task was visual related"""
        if not self.session_memory:
            return False
        last_task = self.session_memory[-1]['task'].lower()
        visual_keywords = ['image', 'visual', 'picture', 'photo', 'video', 'see', 'vision', 'ocr', 'analyze image']
        return any(keyword in last_task for keyword in visual_keywords)

    def process_request(self, task: str, input_type: str = "text", input_data: Optional[str] = None):
        """Process a request by routing it to the appropriate tensor space"""
        print(f"\n{'='*70}")
        print(f"Processing request at: {self.note_current_time()}")
        print(f"Task: {task}")
        print(f"Input type: {input_type}")

        # Route to appropriate tensor space
        selected_tensor_space = self.route_to_tensor_space(task, input_type)

        # Simulate processing (in a real system, this would call the actual tensor space)
        query_analysis = self.analyze_query(task)
        print(f"Processing with tensor space: {selected_tensor_space}")

        # Create changelog entry
        result = f"Processed '{task}' using tensor space: {selected_tensor_space}"
        self.create_changelog_entry(task, selected_tensor_space, result, str(query_analysis['matched_keywords']))

        print(f"Result: {result}")
        print(f"{'='*70}\n")

        return result

    def get_session_memory(self) -> List[Dict[str, Any]]:
        """Get the current session memory"""
        return self.session_memory

    def verify_tensor_space_states(self):
        """Verify current states across tensor spaces"""
        print(f"Session memory contains {len(self.session_memory)} entries")
        for i, entry in enumerate(self.session_memory):
            print(f"  {i+1}. Task: {entry['task'][:50]}... | Tensor: {entry['tensor_space']} | Time: {entry['timestamp']}")

    def run_tensor_space_demo(self):
        """Run a demonstration of the tensor-space architecture"""
        print("\n" + "="*70)
        print("bapX Tensor-Space Architecture Demo")
        print("="*70)

        # Demo different tensor space routing scenarios
        demo_queries = [
            ("Analyze this image for text content", "image"),
            ("Write a Python function to calculate fibonacci sequence", "text"),
            ("Generate a logo for a tech startup", "text"),
            ("Transcribe this audio file", "audio"),
            ("Help me debug this JavaScript code", "text"),
            ("Create an infographic about climate change", "text"),
            ("Explain the concept of quantum computing", "text"),
            ("Read the text from this document", "image"),
            ("Generate a Python script for data analysis", "text")
        ]

        for task, input_type in demo_queries:
            self.process_request(task, input_type)

        print("Tensor-space demo completed!")
        print(f"\nFinal session memory state:")
        self.verify_tensor_space_states()

        print(f"\nRemember: The bapX system implements tensor-space architecture:")
        print(f"- One cognitive system")
        print(f"- Multiple tensor spaces bound to different modalities")
        print(f"- Runtime coordination by Qwen3-VL interpreter")
        print(f"- Time-conscious processing with persistent session memory")


def main():
    print("Starting bapX Tensor-Space Coordinator...")
    coordinator = BapXTensorSpaceCoordinator()

    # Run a demonstration of tensor-space routing
    coordinator.run_tensor_space_demo()

if __name__ == "__main__":
    main()