import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, TaskType
from trl import SFTTrainer
from datasets import Dataset
import json
import yaml
from pathlib import Path

def load_config(config_path="configs/bapx_config.yaml"):
    """Load configuration from YAML file"""
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

def prepare_training_data(data_path="data/bapx_training_data.json"):
    """Prepare training dataset from JSON file"""
    with open(data_path, 'r') as f:
        raw_data = json.load(f)
    
    # Format the conversations for training
    formatted_data = []
    for conv in raw_data["conversations"]:
        # Format as instruction tuning data
        formatted_entry = {
            "prompt": f"### Instruction:\n{conv['instruction']}\n\n### Input:\n{conv['input']}\n\n### Response:\n",
            "completion": f"{conv['output']}\n\n### End"
        }
        formatted_data.append(formatted_entry)
    
    return Dataset.from_list(formatted_data)

def setup_model_and_tokenizer(base_model_name):
    """Setup the primary Qwen3-VL model and tokenizer with 8-bit quantization for delegation training"""

    # Configure 8-bit quantization for the primary model
    bnb_config = BitsAndBytesConfig(
        load_in_8bit=True,  # Use 8-bit quantization
        bnb_8bit_quant_type="q8_0",  # Use Q8_0 quantization type
        bnb_8bit_compute_dtype=torch.float16,  # Use float16 for computations
        bnb_8bit_use_double_quant=False,  # Disable double quantization for better quality
    )

    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(base_model_name)
    tokenizer.pad_token = tokenizer.eos_token

    # Load the primary model (Qwen3VL-8B-Instruct) with quantization
    # This model comes with internal vision capabilities already built-in
    from transformers import AutoModelForCausalLM
    model = AutoModelForCausalLM.from_pretrained(
        base_model_name,
        quantization_config=bnb_config,
        device_map="auto",
        torch_dtype=torch.float16,
        low_cpu_mem_usage=True,
    )

    # Prepare model for k-bit training - this enhances the existing multimodal capabilities
    model = prepare_model_for_kbit_training(model, use_gradient_checkpointing=True)

    return model, tokenizer

def setup_lora_model(model, config):
    """Apply LoRA configuration to the primary model for delegation training"""
    # Use the training_parameters section from config
    training_params = config.get('training_parameters', {})
    lora_config_data = training_params.get('lora_config', {
        'r': 16,
        'alpha': 32,
        'dropout': 0.1,
        'target_modules': ['q_proj', 'v_proj', 'k_proj', 'o_proj', 'gate_proj', 'up_proj', 'down_proj']
    })

    lora_config = LoraConfig(
        r=lora_config_data['r'],
        lora_alpha=lora_config_data['alpha'],
        lora_dropout=lora_config_data['dropout'],
        target_modules=lora_config_data['target_modules'],
        task_type=TaskType.CAUSAL_LM
    )

    model = get_peft_model(model, lora_config)
    return model

def main():
    print("Starting bapX Training for Qwen3-VL Model with Internal Vision...")

    # Load configuration
    config = load_config()
    # Use primary model instead of base model
    primary_model_name = config.get('primary_model', config.get('base_model', 'Qwen3VL-8B-Instruct-Q8_0.gguf'))
    vision_encoder_name = config.get('vision_encoder', 'mmproj-Qwen3VL-8B-Instruct-Q8_0.gguf')
    output_dir = config.get('output_dir', './output/bapx_primary_model')

    print(f"Training primary model: {primary_model_name}")
    print(f"With internal vision encoder: {vision_encoder_name}")
    print(f"Focus: Time-conscious delegation and internal vision coordination")
    print(f"Other external models will be used as-is (Qwen3-Coder-Q8_0.gguf, Flux2-Dev-Q8_0.gguf)")

    # Setup model and tokenizer
    print("Loading Qwen3-VL primary model with internal vision capabilities...")
    print("Note: The vision encoder (mmproj) is internally integrated, not separately loaded")
    model, tokenizer = setup_model_and_tokenizer(primary_model_name)

    # Apply LoRA configuration
    print("Applying LoRA configuration to enhance Qwen3-VL capabilities...")
    model = setup_lora_model(model, config)

    # Show trainable parameters
    model.print_trainable_parameters()

    # Prepare training data
    print("Preparing training data for internal-external coordination...")
    train_dataset = prepare_training_data()

    # Setup training arguments
    from transformers import TrainingArguments

    training_params = config.get('training_parameters', {})
    train_config = config.get('system_operation', {})

    epochs = training_params.get('epochs', 3)
    batch_size = training_params.get('batch_size', 4)
    gradient_accumulation_steps = training_params.get('gradient_accumulation_steps', 4)
    learning_rate = training_params.get('learning_rate', 1e-4)
    warmup_steps = training_params.get('warmup_steps', 100)
    save_steps = training_params.get('save_steps', 500)
    logging_steps = training_params.get('logging_steps', 10)

    training_args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=epochs,
        per_device_train_batch_size=batch_size,
        gradient_accumulation_steps=gradient_accumulation_steps,
        learning_rate=learning_rate,
        warmup_steps=warmup_steps,
        save_steps=save_steps,
        logging_steps=logging_steps,
        save_total_limit=2,
        prediction_loss_only=True,
        remove_unused_columns=False,
        report_to=None,  # Disable reporting to HF hub for simplicity
    )

    # Setup trainer
    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        args=training_args,
        train_dataset=train_dataset,
        dataset_text_field="completion",
        max_seq_length=512,
    )

    print("Starting Qwen3-VL model training process...")
    print("Enhancing Qwen3-VL with:")
    print("- Internal vision-text coordination decision-making")
    print("- Knowledge of when to use internal vision vs. delegate externally")
    print("- Time-conscious decision making")
    print("- AGI research tool adaptation behaviors")
    print("- Session memory with time-based management")
    print("- Understanding of external models' capabilities vs. internal vision")
    print("- Time-first interaction philosophy")
    print("- Coordination between internal mmproj vision and external Q8_0 models")

    # Train the primary model
    trainer.train()

    # Save the trained LoRA adapter for the primary model
    final_output_dir = f"{output_dir}/primary_model_trained"
    trainer.save_model(final_output_dir)

    # Save tokenizer
    tokenizer.save_pretrained(final_output_dir)

    print(f"Training completed! Qwen3-VL LoRA adapter saved to {final_output_dir}")
    print(f"The Qwen3-VL model ({primary_model_name}) is now enhanced with internal-external coordination capabilities.")
    print(f"It knows when to use internal vision (mmproj) vs. delegate to external models (Qwen3-Coder, Flux2-Dev).")

if __name__ == "__main__":
    main()